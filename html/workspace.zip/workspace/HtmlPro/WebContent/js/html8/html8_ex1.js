/**
 * javascript 기본 - 외부 자바스크립트
 */
var now = new Date();
document.write(now);
document.write("안녕하세요");